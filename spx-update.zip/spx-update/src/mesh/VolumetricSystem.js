import * as THREE from 'three';

/**
 * VolumetricSystem — ray-marched volumetric effects (fog, smoke, aura)
 * Uses a fullscreen quad + custom shader material for volumetric rendering.
 */

const volumetricVert = /* glsl */`
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position, 1.0);
}
`;

const volumetricFrag = /* glsl */`
precision highp float;

uniform sampler2D tDepth;
uniform mat4 uInvProjection;
uniform mat4 uInvView;
uniform vec3 uCameraPos;
uniform vec3 uVolumeCenter;
uniform vec3 uVolumeSize;
uniform vec3 uColor;
uniform float uDensity;
uniform float uScattering;
uniform float uTime;
uniform int uSteps;
varying vec2 vUv;

float noise3(vec3 p) {
  return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453);
}

float fbm(vec3 p) {
  float v = 0.0;
  float a = 0.5;
  for (int i = 0; i < 5; i++) {
    v += a * noise3(p);
    p *= 2.0;
    a *= 0.5;
  }
  return v;
}

bool intersectBox(vec3 ro, vec3 rd, vec3 boxMin, vec3 boxMax, out float tNear, out float tFar) {
  vec3 tMin = (boxMin - ro) / rd;
  vec3 tMax = (boxMax - ro) / rd;
  vec3 t1 = min(tMin, tMax);
  vec3 t2 = max(tMin, tMax);
  tNear = max(max(t1.x, t1.y), t1.z);
  tFar  = min(min(t2.x, t2.y), t2.z);
  return tFar > max(tNear, 0.0);
}

void main() {
  vec4 ndcPos = vec4(vUv * 2.0 - 1.0, 1.0, 1.0);
  vec4 viewPos = uInvProjection * ndcPos;
  viewPos /= viewPos.w;
  vec3 worldDir = normalize((uInvView * vec4(viewPos.xyz, 0.0)).xyz);

  vec3 halfSize = uVolumeSize * 0.5;
  vec3 boxMin = uVolumeCenter - halfSize;
  vec3 boxMax = uVolumeCenter + halfSize;

  float tNear, tFar;
  if (!intersectBox(uCameraPos, worldDir, boxMin, boxMax, tNear, tFar)) {
    gl_FragColor = vec4(0.0);
    return;
  }

  tNear = max(tNear, 0.0);
  float stepSize = (tFar - tNear) / float(uSteps);
  float transmittance = 1.0;
  vec3 scatteredLight = vec3(0.0);

  for (int i = 0; i < 64; i++) {
    if (i >= uSteps) break;
    float t = tNear + (float(i) + 0.5) * stepSize;
    vec3 pos = uCameraPos + worldDir * t;
    float density = fbm(pos * 2.0 + uTime * 0.1) * uDensity;
    float extinction = density;
    transmittance *= exp(-extinction * stepSize);
    scatteredLight += uColor * density * uScattering * transmittance * stepSize;
  }

  gl_FragColor = vec4(scatteredLight, 1.0 - transmittance);
}
`;

export class VolumetricSystem {
  constructor(options = {}) {
    this.color = new THREE.Color(options.color ?? 0x88aaff);
    this.density = options.density ?? 0.5;
    this.scattering = options.scattering ?? 0.8;
    this.steps = options.steps ?? 32;
    this.size = options.size
      ? new THREE.Vector3(...options.size)
      : new THREE.Vector3(2, 2, 2);
    this.center = options.center
      ? new THREE.Vector3(...options.center)
      : new THREE.Vector3(0, 0, 0);

    this._time = 0;
    this._mesh = null;
    this._material = null;
    this._build();
  }

  _build() {
    this._material = new THREE.ShaderMaterial({
      vertexShader: volumetricVert,
      fragmentShader: volumetricFrag,
      uniforms: {
        tDepth:         { value: null },
        uInvProjection: { value: new THREE.Matrix4() },
        uInvView:       { value: new THREE.Matrix4() },
        uCameraPos:     { value: new THREE.Vector3() },
        uVolumeCenter:  { value: this.center },
        uVolumeSize:    { value: this.size },
        uColor:         { value: new THREE.Color(this.color) },
        uDensity:       { value: this.density },
        uScattering:    { value: this.scattering },
        uTime:          { value: 0 },
        uSteps:         { value: this.steps },
      },
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });

    const geo = new THREE.PlaneGeometry(2, 2);
    this._mesh = new THREE.Mesh(geo, this._material);
    this._mesh.frustumCulled = false;
    this._mesh.renderOrder = 999;
  }

  update(dt, camera) {
    this._time += dt;
    const u = this._material.uniforms;
    u.uTime.value = this._time;
    u.uCameraPos.value.copy(camera.position);
    u.uInvProjection.value.copy(camera.projectionMatrix).invert();
    u.uInvView.value.copy(camera.matrixWorld);
  }

  get mesh() { return this._mesh; }

  setColor(color) {
    this._material.uniforms.uColor.value.set(color);
  }

  setDensity(d) {
    this._material.uniforms.uDensity.value = d;
  }

  setCenter(x, y, z) {
    this._material.uniforms.uVolumeCenter.value.set(x, y, z);
  }

  dispose() {
    this._mesh.geometry.dispose();
    this._material.dispose();
  }
}

export default VolumetricSystem;
