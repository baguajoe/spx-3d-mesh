import * as THREE from 'three';

/**
 * ClothSystem — position-based dynamics cloth simulation
 */
export class ClothSystem {
  constructor(options = {}) {
    this.width = options.width ?? 1;
    this.height = options.height ?? 1;
    this.segmentsX = options.segmentsX ?? 20;
    this.segmentsY = options.segmentsY ?? 20;
    this.gravity = options.gravity ?? new THREE.Vector3(0, -9.81, 0);
    this.damping = options.damping ?? 0.03;
    this.stiffness = options.stiffness ?? 0.9;
    this.iterations = options.iterations ?? 8;
    this.windForce = options.windForce ?? new THREE.Vector3(0, 0, 0);

    this.particles = [];
    this.constraints = [];
    this.pinnedIndices = new Set(options.pinnedIndices ?? []);

    this._init();
  }

  _init() {
    const dx = this.width / this.segmentsX;
    const dy = this.height / this.segmentsY;

    // Create particles
    for (let y = 0; y <= this.segmentsY; y++) {
      for (let x = 0; x <= this.segmentsX; x++) {
        this.particles.push({
          position: new THREE.Vector3(x * dx - this.width / 2, -y * dy + this.height / 2, 0),
          previous: new THREE.Vector3(x * dx - this.width / 2, -y * dy + this.height / 2, 0),
          acceleration: new THREE.Vector3(),
          mass: 1,
          pinned: this.pinnedIndices.has(y * (this.segmentsX + 1) + x),
        });
      }
    }

    const w = this.segmentsX + 1;
    // Structural constraints
    for (let y = 0; y <= this.segmentsY; y++) {
      for (let x = 0; x <= this.segmentsX; x++) {
        if (x < this.segmentsX) this._addConstraint(y * w + x, y * w + x + 1, dx);
        if (y < this.segmentsY) this._addConstraint(y * w + x, (y + 1) * w + x, dy);
      }
    }
    // Shear constraints
    for (let y = 0; y < this.segmentsY; y++) {
      for (let x = 0; x < this.segmentsX; x++) {
        this._addConstraint(y * w + x, (y + 1) * w + x + 1, Math.sqrt(dx * dx + dy * dy));
        this._addConstraint(y * w + x + 1, (y + 1) * w + x, Math.sqrt(dx * dx + dy * dy));
      }
    }
  }

  _addConstraint(a, b, restLength) {
    this.constraints.push({ a, b, restLength: restLength * this.stiffness });
  }

  step(dt) {
    const dtSq = dt * dt;
    // Verlet integration
    for (const p of this.particles) {
      if (p.pinned) continue;
      const { position, previous, acceleration } = p;
      acceleration.copy(this.gravity);
      acceleration.add(this.windForce);
      const temp = position.clone();
      position.add(position.clone().sub(previous).multiplyScalar(1 - this.damping));
      position.addScaledVector(acceleration, dtSq);
      previous.copy(temp);
    }
    // Satisfy constraints
    for (let iter = 0; iter < this.iterations; iter++) {
      for (const { a, b, restLength } of this.constraints) {
        const pa = this.particles[a];
        const pb = this.particles[b];
        const delta = pb.position.clone().sub(pa.position);
        const dist = delta.length() || 0.0001;
        const correction = delta.multiplyScalar((dist - restLength) / dist * 0.5);
        if (!pa.pinned) pa.position.add(correction);
        if (!pb.pinned) pb.position.sub(correction);
      }
    }
  }

  getPositions() {
    return this.particles.map(p => p.position);
  }

  updateGeometry(geometry) {
    const pos = geometry.attributes.position;
    for (let i = 0; i < this.particles.length; i++) {
      pos.setXYZ(i, this.particles[i].position.x, this.particles[i].position.y, this.particles[i].position.z);
    }
    pos.needsUpdate = true;
    geometry.computeVertexNormals();
  }

  setWind(x, y, z) {
    this.windForce.set(x, y, z);
  }

  pin(index) { this.particles[index] && (this.particles[index].pinned = true); }
  unpin(index) { this.particles[index] && (this.particles[index].pinned = false); }
  reset() { this._init(); }
}

export default ClothSystem;
