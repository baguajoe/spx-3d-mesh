import * as THREE from 'three';

/**
 * GeometryEngine — 24 procedural primitives
 */
export const PRIMITIVE_TYPES = [
  'box', 'sphere', 'cylinder', 'cone', 'torus', 'torusKnot',
  'plane', 'circle', 'ring', 'capsule', 'icosphere', 'octahedron',
  'tetrahedron', 'dodecahedron', 'lathe', 'tube', 'extrude', 'text3d',
  'grid', 'stairs', 'arch', 'arrow', 'star', 'helix'
];

export class GeometryEngine {
  static create(type, params = {}) {
    switch (type) {
      case 'box':
        return new THREE.BoxGeometry(
          params.width ?? 1, params.height ?? 1, params.depth ?? 1,
          params.segW ?? 1, params.segH ?? 1, params.segD ?? 1
        );
      case 'sphere':
        return new THREE.SphereGeometry(
          params.radius ?? 0.5, params.widthSegs ?? 32, params.heightSegs ?? 16
        );
      case 'cylinder':
        return new THREE.CylinderGeometry(
          params.radiusTop ?? 0.5, params.radiusBottom ?? 0.5,
          params.height ?? 1, params.radialSegs ?? 32, params.heightSegs ?? 1,
          params.openEnded ?? false
        );
      case 'cone':
        return new THREE.ConeGeometry(
          params.radius ?? 0.5, params.height ?? 1,
          params.radialSegs ?? 32, params.heightSegs ?? 1
        );
      case 'torus':
        return new THREE.TorusGeometry(
          params.radius ?? 0.4, params.tube ?? 0.15,
          params.radialSegs ?? 16, params.tubularSegs ?? 100
        );
      case 'torusKnot':
        return new THREE.TorusKnotGeometry(
          params.radius ?? 0.4, params.tube ?? 0.1,
          params.tubularSegs ?? 100, params.radialSegs ?? 16,
          params.p ?? 2, params.q ?? 3
        );
      case 'plane':
        return new THREE.PlaneGeometry(
          params.width ?? 1, params.height ?? 1,
          params.widthSegs ?? 1, params.heightSegs ?? 1
        );
      case 'circle':
        return new THREE.CircleGeometry(params.radius ?? 0.5, params.segments ?? 32);
      case 'ring':
        return new THREE.RingGeometry(
          params.innerRadius ?? 0.2, params.outerRadius ?? 0.5,
          params.thetaSegs ?? 32
        );
      case 'capsule':
        return new THREE.CapsuleGeometry(
          params.radius ?? 0.3, params.length ?? 0.8,
          params.capSegs ?? 4, params.radialSegs ?? 16
        );
      case 'icosphere':
        return new THREE.IcosahedronGeometry(params.radius ?? 0.5, params.detail ?? 2);
      case 'octahedron':
        return new THREE.OctahedronGeometry(params.radius ?? 0.5, params.detail ?? 0);
      case 'tetrahedron':
        return new THREE.TetrahedronGeometry(params.radius ?? 0.5, params.detail ?? 0);
      case 'dodecahedron':
        return new THREE.DodecahedronGeometry(params.radius ?? 0.5, params.detail ?? 0);
      case 'lathe': {
        const pts = params.points ?? [
          new THREE.Vector2(0.2, 0), new THREE.Vector2(0.3, 0.2),
          new THREE.Vector2(0.25, 0.5), new THREE.Vector2(0.1, 0.8)
        ];
        return new THREE.LatheGeometry(pts, params.segments ?? 24, params.phiStart ?? 0, params.phiLength ?? Math.PI * 2);
      }
      case 'tube': {
        const path = params.path ?? new THREE.CatmullRomCurve3([
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(0.5, 0.5, 0),
          new THREE.Vector3(1, 0, 0),
        ]);
        return new THREE.TubeGeometry(path, params.tubularSegs ?? 20, params.radius ?? 0.1, params.radialSegs ?? 8, params.closed ?? false);
      }
      case 'grid': {
        const g = new THREE.BufferGeometry();
        const size = params.size ?? 2;
        const divs = params.divisions ?? 10;
        const step = size / divs;
        const half = size / 2;
        const verts = [];
        for (let i = 0; i <= divs; i++) {
          const p = -half + i * step;
          verts.push(p, 0, -half, p, 0, half);
          verts.push(-half, 0, p, half, 0, p);
        }
        g.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
        return g;
      }
      case 'stairs': {
        const steps = params.steps ?? 8;
        const stepW = params.width ?? 1;
        const stepH = (params.height ?? 1) / steps;
        const stepD = (params.depth ?? 1) / steps;
        const shape = new THREE.Shape();
        shape.moveTo(0, 0);
        for (let i = 0; i < steps; i++) {
          shape.lineTo(i * stepD, i * stepH);
          shape.lineTo(i * stepD, (i + 1) * stepH);
        }
        shape.lineTo(steps * stepD, steps * stepH);
        shape.lineTo(steps * stepD, 0);
        shape.closePath();
        return new THREE.ExtrudeGeometry(shape, { depth: stepW, bevelEnabled: false });
      }
      case 'arch': {
        const w = params.width ?? 1;
        const h = params.height ?? 1.5;
        const thick = params.thickness ?? 0.2;
        const shape = new THREE.Shape();
        shape.moveTo(-w / 2, 0);
        shape.lineTo(-w / 2, h - w / 2);
        shape.absarc(0, h - w / 2, w / 2, Math.PI, 0, true);
        shape.lineTo(w / 2, 0);
        shape.lineTo(w / 2 - thick, 0);
        shape.lineTo(w / 2 - thick, h - w / 2);
        shape.absarc(0, h - w / 2, w / 2 - thick, 0, Math.PI, false);
        shape.lineTo(-w / 2 + thick, 0);
        shape.closePath();
        return new THREE.ExtrudeGeometry(shape, { depth: params.depth ?? 0.2, bevelEnabled: false });
      }
      case 'arrow': {
        const shape = new THREE.Shape();
        const shaftW = params.shaftWidth ?? 0.1;
        const shaftH = params.shaftHeight ?? 0.6;
        const headW = params.headWidth ?? 0.3;
        const headH = params.headHeight ?? 0.4;
        shape.moveTo(-shaftW / 2, 0);
        shape.lineTo(-shaftW / 2, shaftH);
        shape.lineTo(-headW / 2, shaftH);
        shape.lineTo(0, shaftH + headH);
        shape.lineTo(headW / 2, shaftH);
        shape.lineTo(shaftW / 2, shaftH);
        shape.lineTo(shaftW / 2, 0);
        shape.closePath();
        return new THREE.ExtrudeGeometry(shape, { depth: params.depth ?? 0.1, bevelEnabled: false });
      }
      case 'star': {
        const shape = new THREE.Shape();
        const outerR = params.outerRadius ?? 0.5;
        const innerR = params.innerRadius ?? 0.2;
        const pts2 = params.points ?? 5;
        for (let i = 0; i < pts2 * 2; i++) {
          const r = i % 2 === 0 ? outerR : innerR;
          const angle = (i / (pts2 * 2)) * Math.PI * 2 - Math.PI / 2;
          if (i === 0) shape.moveTo(Math.cos(angle) * r, Math.sin(angle) * r);
          else shape.lineTo(Math.cos(angle) * r, Math.sin(angle) * r);
        }
        shape.closePath();
        return new THREE.ExtrudeGeometry(shape, { depth: params.depth ?? 0.1, bevelEnabled: false });
      }
      case 'helix': {
        const helixPath = new THREE.Curve();
        const turns = params.turns ?? 3;
        const radius = params.radius ?? 0.4;
        const rise = params.rise ?? 1.0;
        helixPath.getPoint = (t) => {
          const angle = t * Math.PI * 2 * turns;
          return new THREE.Vector3(
            Math.cos(angle) * radius,
            t * rise - rise / 2,
            Math.sin(angle) * radius
          );
        };
        return new THREE.TubeGeometry(helixPath, params.tubularSegs ?? 120, params.tubeRadius ?? 0.05, params.radialSegs ?? 8, false);
      }
      case 'extrude':
      case 'text3d':
      default:
        return new THREE.BoxGeometry(1, 1, 1);
    }
  }

  static getDefaults(type) {
    const defaults = {
      box: { width: 1, height: 1, depth: 1, segW: 1, segH: 1, segD: 1 },
      sphere: { radius: 0.5, widthSegs: 32, heightSegs: 16 },
      cylinder: { radiusTop: 0.5, radiusBottom: 0.5, height: 1, radialSegs: 32 },
      cone: { radius: 0.5, height: 1, radialSegs: 32 },
      torus: { radius: 0.4, tube: 0.15, radialSegs: 16, tubularSegs: 100 },
      torusKnot: { radius: 0.4, tube: 0.1, p: 2, q: 3 },
      plane: { width: 1, height: 1, widthSegs: 1, heightSegs: 1 },
      circle: { radius: 0.5, segments: 32 },
      ring: { innerRadius: 0.2, outerRadius: 0.5, thetaSegs: 32 },
      capsule: { radius: 0.3, length: 0.8, capSegs: 4, radialSegs: 16 },
      icosphere: { radius: 0.5, detail: 2 },
      octahedron: { radius: 0.5, detail: 0 },
      tetrahedron: { radius: 0.5, detail: 0 },
      dodecahedron: { radius: 0.5, detail: 0 },
      lathe: { segments: 24 },
      tube: { tubularSegs: 20, radius: 0.1, radialSegs: 8 },
      grid: { size: 2, divisions: 10 },
      stairs: { steps: 8, width: 1, height: 1, depth: 1 },
      arch: { width: 1, height: 1.5, thickness: 0.2, depth: 0.2 },
      arrow: { shaftWidth: 0.1, shaftHeight: 0.6, headWidth: 0.3, headHeight: 0.4, depth: 0.1 },
      star: { outerRadius: 0.5, innerRadius: 0.2, points: 5, depth: 0.1 },
      helix: { turns: 3, radius: 0.4, rise: 1.0, tubeRadius: 0.05 },
    };
    return defaults[type] || {};
  }
}

export default GeometryEngine;
