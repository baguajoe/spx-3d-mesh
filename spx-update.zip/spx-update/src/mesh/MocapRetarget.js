import * as THREE from 'three';

/**
 * MocapRetarget — retargets BVH/Mixamo bone data onto a target skeleton
 */

export const STANDARD_BONE_MAP = {
  Hips:          'Hips',
  Spine:         'Spine',
  Spine1:        'Spine1',
  Spine2:        'Spine2',
  Neck:          'Neck',
  Head:          'Head',
  LeftShoulder:  'LeftShoulder',
  LeftArm:       'LeftArm',
  LeftForeArm:   'LeftForeArm',
  LeftHand:      'LeftHand',
  RightShoulder: 'RightShoulder',
  RightArm:      'RightArm',
  RightForeArm:  'RightForeArm',
  RightHand:     'RightHand',
  LeftUpLeg:     'LeftUpLeg',
  LeftLeg:       'LeftLeg',
  LeftFoot:      'LeftFoot',
  LeftToeBase:   'LeftToeBase',
  RightUpLeg:    'RightUpLeg',
  RightLeg:      'RightLeg',
  RightFoot:     'RightFoot',
  RightToeBase:  'RightToeBase',
};

export class MocapRetarget {
  constructor(sourceSkeleton, targetSkeleton, boneMap = STANDARD_BONE_MAP) {
    this.source = sourceSkeleton;
    this.target = targetSkeleton;
    this.boneMap = boneMap;

    this._srcBones = {};
    this._tgtBones = {};
    this._tPoseSource = {};
    this._tPoseTarget = {};

    this._indexBones();
    this._captureTPose();
  }

  _indexBones() {
    if (this.source) {
      this.source.bones.forEach(b => { this._srcBones[b.name] = b; });
    }
    if (this.target) {
      this.target.bones.forEach(b => { this._tgtBones[b.name] = b; });
    }
  }

  _captureTPose() {
    for (const [srcName, tgtName] of Object.entries(this.boneMap)) {
      const sb = this._srcBones[srcName];
      const tb = this._tgtBones[tgtName];
      if (sb) this._tPoseSource[srcName] = sb.quaternion.clone();
      if (tb) this._tPoseTarget[tgtName] = tb.quaternion.clone();
    }
  }

  /**
   * Apply one frame of retargeted motion.
   * sourceRotations: { [boneName]: THREE.Quaternion }
   * sourceRootPos:   THREE.Vector3 (optional)
   */
  applyFrame(sourceRotations, sourceRootPos = null, scale = 1.0) {
    for (const [srcName, tgtName] of Object.entries(this.boneMap)) {
      const srcQ = sourceRotations[srcName];
      if (!srcQ) continue;

      const tb = this._tgtBones[tgtName];
      if (!tb) continue;

      const tpSrc = this._tPoseSource[srcName] || new THREE.Quaternion();
      const tpTgt = this._tPoseTarget[tgtName] || new THREE.Quaternion();

      // retarget: tgtTPose * (srcTPose^-1 * srcQ)
      const localDelta = tpSrc.clone().invert().multiply(srcQ);
      tb.quaternion.copy(tpTgt).multiply(localDelta);
    }

    if (sourceRootPos) {
      const rootBone = this._tgtBones['Hips'];
      if (rootBone) {
        rootBone.position.copy(sourceRootPos).multiplyScalar(scale);
      }
    }

    if (this.target) this.target.update();
  }

  /**
   * Batch retarget an AnimationClip from source to target skeleton.
   */
  retargetClip(clip, targetSkeleton = this.target) {
    const newTracks = [];
    for (const track of clip.tracks) {
      const boneName = track.name.split('.')[0];
      const prop = track.name.split('.')[1];
      // Find mapped bone
      const tgtName = this.boneMap[boneName];
      if (!tgtName) continue;
      const tb = this._tgtBones[tgtName];
      if (!tb) continue;

      if (prop === 'quaternion') {
        const tpSrc = this._tPoseSource[boneName] || new THREE.Quaternion();
        const tpTgt = this._tPoseTarget[tgtName] || new THREE.Quaternion();
        const values = [];
        for (let i = 0; i < track.values.length; i += 4) {
          const srcQ = new THREE.Quaternion(
            track.values[i], track.values[i + 1],
            track.values[i + 2], track.values[i + 3]
          );
          const delta = tpSrc.clone().invert().multiply(srcQ);
          const out = tpTgt.clone().multiply(delta);
          values.push(out.x, out.y, out.z, out.w);
        }
        newTracks.push(new THREE.QuaternionKeyframeTrack(
          `${tgtName}.quaternion`, track.times, values
        ));
      } else if (prop === 'position' && boneName === 'Hips') {
        newTracks.push(new THREE.VectorKeyframeTrack(
          `${tgtName}.position`, track.times, [...track.values]
        ));
      }
    }

    return new THREE.AnimationClip(clip.name + '_retargeted', clip.duration, newTracks);
  }

  updateBoneMap(map) {
    this.boneMap = { ...this.boneMap, ...map };
    this._indexBones();
    this._captureTPose();
  }

  dispose() {
    this._srcBones = {};
    this._tgtBones = {};
    this._tPoseSource = {};
    this._tPoseTarget = {};
  }
}

export default MocapRetarget;
