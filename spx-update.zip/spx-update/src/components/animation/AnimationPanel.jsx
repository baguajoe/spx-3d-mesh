import React, { useState, useRef } from 'react';

export default function AnimationPanel() {
  const [playing, setPlaying] = useState(false);
  const [frame, setFrame] = useState(0);
  const [fps, setFps] = useState(30);
  const [totalFrames, setTotalFrames] = useState(120);
  const [clips, setClips] = useState([
    { id: 1, name: 'Idle', start: 0, end: 60, active: true },
    { id: 2, name: 'Walk', start: 61, end: 100, active: false },
  ]);

  return (
    <div className="panel-section">
      <div className="panel-header">Animation</div>
      <div className="panel-group">
        <div className="panel-label">Timeline</div>
        <div className="timeline-bar">
          <input type="range" min="0" max={totalFrames} value={frame}
            onChange={e => setFrame(+e.target.value)} className="timeline-scrubber" />
        </div>
        <div className="panel-row transport">
          <button className="transport-btn" onClick={() => setFrame(0)}>⏮</button>
          <button className="transport-btn" onClick={() => setFrame(Math.max(0, frame - 1))}>◀</button>
          <button className="transport-btn primary" onClick={() => setPlaying(!playing)}>
            {playing ? '⏸' : '▶'}
          </button>
          <button className="transport-btn" onClick={() => setFrame(Math.min(totalFrames, frame + 1))}>▶</button>
          <button className="transport-btn" onClick={() => setFrame(totalFrames)}>⏭</button>
          <span className="frame-display">{frame} / {totalFrames}</span>
        </div>
        <div className="panel-row">
          <label>FPS</label>
          <select value={fps} onChange={e => setFps(+e.target.value)}>
            <option value={24}>24</option>
            <option value={30}>30</option>
            <option value={60}>60</option>
            <option value={120}>120</option>
          </select>
        </div>
      </div>

      <div className="panel-group">
        <div className="panel-label">Clips</div>
        {clips.map(c => (
          <div key={c.id} className={`panel-item ${c.active ? 'active' : ''}`}
            onClick={() => setClips(clips.map(cc => ({ ...cc, active: cc.id === c.id })))}>
            <span>{c.name}</span>
            <span className="clip-range">{c.start}–{c.end}</span>
          </div>
        ))}
        <button className="panel-btn">+ New Clip</button>
      </div>

      <div className="panel-group">
        <div className="panel-label">Keyframes</div>
        <div className="panel-row">
          <button className="panel-btn">Insert Key</button>
          <button className="panel-btn">Delete Key</button>
          <button className="panel-btn">Auto Key</button>
        </div>
      </div>

      <div className="panel-group">
        <div className="panel-label">Graph Editor</div>
        <div className="panel-row">
          <button className="panel-btn">Open Graph</button>
          <select><option>Bezier</option><option>Linear</option><option>Constant</option></select>
        </div>
      </div>
    </div>
  );
}
