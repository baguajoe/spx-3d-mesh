import React, { useState } from 'react';

export default function MocapPanel() {
  const [source, setSource] = useState('file');
  const [retarget, setRetarget] = useState({ scale: 1.0, hipOffset: 0, rootMotion: true });
  const [status, setStatus] = useState('idle');

  return (
    <div className="panel-section">
      <div className="panel-header">Mocap / Retarget</div>
      <div className="panel-group">
        <div className="panel-label">Source</div>
        <div className="panel-row">
          {['file', 'live', 'library'].map(s => (
            <button key={s} className={`panel-btn small ${source === s ? 'active' : ''}`}
              onClick={() => setSource(s)}>{s}</button>
          ))}
        </div>
        {source === 'file' && (
          <div className="panel-row">
            <button className="panel-btn full-width">Load BVH / FBX</button>
          </div>
        )}
        {source === 'live' && (
          <div className="panel-row">
            <button className="panel-btn full-width primary">Connect Device</button>
          </div>
        )}
        {source === 'library' && (
          <div className="panel-row">
            <select className="full-width">
              <option>Mixamo — Walk</option>
              <option>Mixamo — Run</option>
              <option>Mixamo — Dance</option>
              <option>CMU — Idle</option>
            </select>
          </div>
        )}
      </div>

      <div className="panel-group">
        <div className="panel-label">Retarget Settings</div>
        <div className="panel-row">
          <label>Scale</label>
          <input type="range" min="0.5" max="2" step="0.01" value={retarget.scale}
            onChange={e => setRetarget({ ...retarget, scale: +e.target.value })} />
          <span>{retarget.scale.toFixed(2)}</span>
        </div>
        <div className="panel-row">
          <label>Hip Offset</label>
          <input type="range" min="-1" max="1" step="0.01" value={retarget.hipOffset}
            onChange={e => setRetarget({ ...retarget, hipOffset: +e.target.value })} />
          <span>{retarget.hipOffset.toFixed(2)}</span>
        </div>
        <div className="panel-row">
          <input type="checkbox" checked={retarget.rootMotion}
            onChange={e => setRetarget({ ...retarget, rootMotion: e.target.checked })} />
          <label>Root Motion</label>
        </div>
      </div>

      <div className="panel-group">
        <div className="panel-row">
          <button className="panel-btn full-width primary"
            onClick={() => { setStatus('retargeting'); setTimeout(() => setStatus('done'), 1200); }}>
            {status === 'idle' ? 'Retarget' : status === 'retargeting' ? 'Processing...' : '✓ Done'}
          </button>
        </div>
        <div className="panel-row">
          <button className="panel-btn">Bone Map</button>
          <button className="panel-btn">Bake to Rig</button>
          <button className="panel-btn">Export</button>
        </div>
      </div>
    </div>
  );
}
