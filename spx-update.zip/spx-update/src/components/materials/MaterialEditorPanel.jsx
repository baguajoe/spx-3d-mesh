import React, { useState } from 'react';

const defaultMaterials = [
  { id: 1, name: 'Body_Skin', type: 'PBR', color: '#e8c4a0', roughness: 0.6, metalness: 0.0, opacity: 1.0 },
  { id: 2, name: 'Eyes', type: 'PBR', color: '#4488cc', roughness: 0.1, metalness: 0.0, opacity: 1.0 },
  { id: 3, name: 'Hair_Base', type: 'PBR', color: '#3a2a1a', roughness: 0.8, metalness: 0.0, opacity: 1.0 },
];

export default function MaterialEditorPanel() {
  const [materials, setMaterials] = useState(defaultMaterials);
  const [selected, setSelected] = useState(1);
  const mat = materials.find(m => m.id === selected) || materials[0];

  const update = (key, val) => setMaterials(materials.map(m => m.id === selected ? { ...m, [key]: val } : m));

  return (
    <div className="panel-section">
      <div className="panel-header">Material Editor</div>
      <div className="panel-group">
        <div className="panel-label">Materials</div>
        <div className="material-list">
          {materials.map(m => (
            <div key={m.id} className={`material-item ${selected === m.id ? 'active' : ''}`}
              onClick={() => setSelected(m.id)}>
              <div className="mat-swatch" style={{ background: m.color }} />
              <span>{m.name}</span>
              <span className="mat-type">{m.type}</span>
            </div>
          ))}
        </div>
        <button className="panel-btn" onClick={() => {
          const id = Date.now();
          setMaterials([...materials, { id, name: 'New Material', type: 'PBR', color: '#888888', roughness: 0.5, metalness: 0.0, opacity: 1.0 }]);
          setSelected(id);
        }}>+ New Material</button>
      </div>

      {mat && (
        <div className="panel-group">
          <div className="panel-label">Properties — {mat.name}</div>
          <div className="panel-row">
            <label>Type</label>
            <select value={mat.type} onChange={e => update('type', e.target.value)}>
              <option>PBR</option><option>Toon</option><option>Unlit</option>
              <option>Glass</option><option>Subsurface</option>
            </select>
          </div>
          <div className="panel-row">
            <label>Base Color</label>
            <input type="color" value={mat.color} onChange={e => update('color', e.target.value)} />
          </div>
          <div className="panel-row">
            <label>Roughness</label>
            <input type="range" min="0" max="1" step="0.01" value={mat.roughness}
              onChange={e => update('roughness', +e.target.value)} />
            <span>{mat.roughness.toFixed(2)}</span>
          </div>
          <div className="panel-row">
            <label>Metalness</label>
            <input type="range" min="0" max="1" step="0.01" value={mat.metalness}
              onChange={e => update('metalness', +e.target.value)} />
            <span>{mat.metalness.toFixed(2)}</span>
          </div>
          <div className="panel-row">
            <label>Opacity</label>
            <input type="range" min="0" max="1" step="0.01" value={mat.opacity}
              onChange={e => update('opacity', +e.target.value)} />
            <span>{mat.opacity.toFixed(2)}</span>
          </div>
          <div className="panel-row">
            <button className="panel-btn">Assign Texture</button>
            <button className="panel-btn">Node Editor</button>
          </div>
        </div>
      )}
    </div>
  );
}
