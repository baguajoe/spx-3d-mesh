import React, { useState } from 'react';

export default function TexturePaintPanel() {
  const [brush, setBrush] = useState({ size: 20, strength: 0.8, hardness: 0.5, color: '#ff4444', mode: 'draw' });
  const [channel, setChannel] = useState('albedo');

  return (
    <div className="panel-section">
      <div className="panel-header">Texture Paint</div>
      <div className="panel-group">
        <div className="panel-label">Channel</div>
        <div className="panel-row channel-row">
          {['albedo', 'roughness', 'metalness', 'normal', 'emission'].map(c => (
            <button key={c} className={`channel-btn ${channel === c ? 'active' : ''}`}
              onClick={() => setChannel(c)}>{c}</button>
          ))}
        </div>
      </div>
      <div className="panel-group">
        <div className="panel-label">Brush</div>
        <div className="panel-row">
          <label>Mode</label>
          <select value={brush.mode} onChange={e => setBrush({ ...brush, mode: e.target.value })}>
            <option value="draw">Draw</option>
            <option value="erase">Erase</option>
            <option value="smear">Smear</option>
            <option value="fill">Fill</option>
            <option value="clone">Clone</option>
          </select>
        </div>
        <div className="panel-row">
          <label>Color</label>
          <input type="color" value={brush.color} onChange={e => setBrush({ ...brush, color: e.target.value })} />
        </div>
        <div className="panel-row">
          <label>Size</label>
          <input type="range" min="1" max="200" value={brush.size}
            onChange={e => setBrush({ ...brush, size: +e.target.value })} />
          <span>{brush.size}px</span>
        </div>
        <div className="panel-row">
          <label>Strength</label>
          <input type="range" min="0" max="1" step="0.01" value={brush.strength}
            onChange={e => setBrush({ ...brush, strength: +e.target.value })} />
          <span>{(brush.strength * 100).toFixed(0)}%</span>
        </div>
        <div className="panel-row">
          <label>Hardness</label>
          <input type="range" min="0" max="1" step="0.01" value={brush.hardness}
            onChange={e => setBrush({ ...brush, hardness: +e.target.value })} />
          <span>{(brush.hardness * 100).toFixed(0)}%</span>
        </div>
      </div>
      <div className="panel-group">
        <div className="panel-row">
          <button className="panel-btn">New Layer</button>
          <button className="panel-btn">Merge Down</button>
          <button className="panel-btn">Bake</button>
        </div>
      </div>
    </div>
  );
}
