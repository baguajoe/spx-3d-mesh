import React, { useState } from 'react';

export default function HairEditorPanel() {
  const [systems, setSystems] = useState([
    { id: 1, name: 'Scalp Hair', type: 'particle', count: 50000, enabled: true },
    { id: 2, name: 'Eyebrows', type: 'mesh', count: 500, enabled: true },
  ]);
  const [selected, setSelected] = useState(1);
  const [props, setProps] = useState({ length: 0.3, clump: 0.5, frizz: 0.1, wave: 0.2, gravity: 0.3 });

  return (
    <div className="panel-section">
      <div className="panel-header">Hair Editor</div>
      <div className="panel-group">
        <div className="panel-label">Hair Systems</div>
        {systems.map(s => (
          <div key={s.id} className={`panel-item ${selected === s.id ? 'active' : ''}`}
            onClick={() => setSelected(s.id)}>
            <input type="checkbox" checked={s.enabled}
              onChange={e => setSystems(systems.map(ss => ss.id === s.id ? { ...ss, enabled: e.target.checked } : ss))}
              onClick={e => e.stopPropagation()} />
            <span>{s.name}</span>
            <span className="layer-badge">{s.type}</span>
          </div>
        ))}
        <button className="panel-btn">+ Add System</button>
      </div>

      <div className="panel-group">
        <div className="panel-label">Properties</div>
        {Object.entries(props).map(([k, v]) => (
          <div className="panel-row" key={k}>
            <label>{k}</label>
            <input type="range" min="0" max="1" step="0.01" value={v}
              onChange={e => setProps({ ...props, [k]: +e.target.value })} />
            <span>{v.toFixed(2)}</span>
          </div>
        ))}
      </div>

      <div className="panel-group">
        <div className="panel-label">Grooming</div>
        <div className="panel-row">
          {['comb', 'cut', 'smooth', 'puff', 'twist'].map(t => (
            <button key={t} className="panel-btn small">{t}</button>
          ))}
        </div>
      </div>

      <div className="panel-group">
        <div className="panel-label">Style Presets</div>
        <div className="panel-row">
          {['Short', 'Long', 'Curly', 'Braids', 'Dreadlocks'].map(p => (
            <button key={p} className="panel-btn small">{p}</button>
          ))}
        </div>
      </div>
    </div>
  );
}
