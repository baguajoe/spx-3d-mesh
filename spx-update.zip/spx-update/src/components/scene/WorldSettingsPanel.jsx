import React, { useState } from 'react';

export default function WorldSettingsPanel() {
  const [sky, setSky] = useState({ type: 'hdri', color: '#87ceeb', turbidity: 2.0, sunAngle: 45 });
  const [fog, setFog] = useState({ enabled: false, type: 'linear', color: '#ccddee', near: 10, far: 100 });
  const [physics, setPhysics] = useState({ gravity: -9.81, substeps: 4 });

  return (
    <div className="panel-section">
      <div className="panel-header">World Settings</div>
      <div className="panel-group">
        <div className="panel-label">Sky</div>
        <div className="panel-row">
          <label>Type</label>
          <select value={sky.type} onChange={e => setSky({ ...sky, type: e.target.value })}>
            <option value="hdri">HDRI</option>
            <option value="procedural">Procedural</option>
            <option value="solid">Solid Color</option>
            <option value="gradient">Gradient</option>
          </select>
        </div>
        {sky.type === 'procedural' && <>
          <div className="panel-row">
            <label>Turbidity</label>
            <input type="range" min="0" max="10" step="0.1" value={sky.turbidity}
              onChange={e => setSky({ ...sky, turbidity: +e.target.value })} />
            <span>{sky.turbidity.toFixed(1)}</span>
          </div>
          <div className="panel-row">
            <label>Sun Angle</label>
            <input type="range" min="0" max="180" value={sky.sunAngle}
              onChange={e => setSky({ ...sky, sunAngle: +e.target.value })} />
            <span>{sky.sunAngle}°</span>
          </div>
        </>}
        {(sky.type === 'solid' || sky.type === 'gradient') && (
          <div className="panel-row">
            <label>Color</label>
            <input type="color" value={sky.color} onChange={e => setSky({ ...sky, color: e.target.value })} />
          </div>
        )}
        {sky.type === 'hdri' && (
          <div className="panel-row">
            <button className="panel-btn full-width">Load HDRI</button>
          </div>
        )}
      </div>

      <div className="panel-group">
        <div className="panel-label">
          <input type="checkbox" checked={fog.enabled}
            onChange={e => setFog({ ...fog, enabled: e.target.checked })} />
          Fog
        </div>
        {fog.enabled && <>
          <div className="panel-row">
            <label>Type</label>
            <select value={fog.type} onChange={e => setFog({ ...fog, type: e.target.value })}>
              <option value="linear">Linear</option>
              <option value="exp">Exponential</option>
              <option value="exp2">Exp²</option>
            </select>
          </div>
          <div className="panel-row">
            <label>Color</label>
            <input type="color" value={fog.color} onChange={e => setFog({ ...fog, color: e.target.value })} />
          </div>
          <div className="panel-row">
            <label>Near</label>
            <input type="number" value={fog.near} onChange={e => setFog({ ...fog, near: +e.target.value })} />
            <label>Far</label>
            <input type="number" value={fog.far} onChange={e => setFog({ ...fog, far: +e.target.value })} />
          </div>
        </>}
      </div>

      <div className="panel-group">
        <div className="panel-label">Physics World</div>
        <div className="panel-row">
          <label>Gravity</label>
          <input type="number" step="0.1" value={physics.gravity}
            onChange={e => setPhysics({ ...physics, gravity: +e.target.value })} />
        </div>
        <div className="panel-row">
          <label>Substeps</label>
          <input type="number" min="1" max="16" value={physics.substeps}
            onChange={e => setPhysics({ ...physics, substeps: +e.target.value })} />
        </div>
      </div>
    </div>
  );
}
