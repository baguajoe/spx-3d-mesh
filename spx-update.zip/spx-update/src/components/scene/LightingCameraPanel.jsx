import React, { useState } from 'react';

export default function LightingCameraPanel() {
  const [lights, setLights] = useState([
    { id: 1, name: 'Sun', type: 'directional', intensity: 1.0, color: '#ffffff', enabled: true },
    { id: 2, name: 'Fill', type: 'point', intensity: 0.5, color: '#aaccff', enabled: true },
  ]);
  const [camera, setCamera] = useState({ fov: 60, near: 0.1, far: 1000, exposure: 1.0 });
  const [env, setEnv] = useState({ preset: 'studio', intensity: 1.0 });

  return (
    <div className="panel-section">
      <div className="panel-header">Lighting &amp; Camera</div>
      <div className="panel-group">
        <div className="panel-label">Camera</div>
        <div className="panel-row">
          <label>FOV</label>
          <input type="range" min="20" max="120" value={camera.fov}
            onChange={e => setCamera({ ...camera, fov: +e.target.value })} />
          <span>{camera.fov}°</span>
        </div>
        <div className="panel-row">
          <label>Near</label>
          <input type="number" step="0.01" value={camera.near}
            onChange={e => setCamera({ ...camera, near: +e.target.value })} />
        </div>
        <div className="panel-row">
          <label>Far</label>
          <input type="number" step="10" value={camera.far}
            onChange={e => setCamera({ ...camera, far: +e.target.value })} />
        </div>
        <div className="panel-row">
          <label>Exposure</label>
          <input type="range" min="0.1" max="4" step="0.1" value={camera.exposure}
            onChange={e => setCamera({ ...camera, exposure: +e.target.value })} />
          <span>{camera.exposure.toFixed(1)}</span>
        </div>
      </div>

      <div className="panel-group">
        <div className="panel-label">Environment</div>
        <div className="panel-row">
          <label>Preset</label>
          <select value={env.preset} onChange={e => setEnv({ ...env, preset: e.target.value })}>
            <option value="studio">Studio</option>
            <option value="outdoor">Outdoor</option>
            <option value="night">Night</option>
            <option value="sunset">Sunset</option>
            <option value="none">None</option>
          </select>
        </div>
        <div className="panel-row">
          <label>Intensity</label>
          <input type="range" min="0" max="3" step="0.1" value={env.intensity}
            onChange={e => setEnv({ ...env, intensity: +e.target.value })} />
          <span>{env.intensity.toFixed(1)}</span>
        </div>
      </div>

      <div className="panel-group">
        <div className="panel-label">Lights</div>
        {lights.map(light => (
          <div key={light.id} className="panel-row light-row">
            <input type="checkbox" checked={light.enabled}
              onChange={e => setLights(lights.map(l => l.id === light.id ? { ...l, enabled: e.target.checked } : l))} />
            <span className="light-name">{light.name}</span>
            <span className="light-type">{light.type}</span>
            <input type="color" value={light.color}
              onChange={e => setLights(lights.map(l => l.id === light.id ? { ...l, color: e.target.value } : l))} />
            <input type="range" min="0" max="3" step="0.1" value={light.intensity}
              onChange={e => setLights(lights.map(l => l.id === light.id ? { ...l, intensity: +e.target.value } : l))} />
            <span>{light.intensity.toFixed(1)}</span>
          </div>
        ))}
        <button className="panel-btn" onClick={() => setLights([...lights, {
          id: Date.now(), name: `Light ${lights.length + 1}`, type: 'point',
          intensity: 1, color: '#ffffff', enabled: true
        }])}>+ Add Light</button>
      </div>
    </div>
  );
}
