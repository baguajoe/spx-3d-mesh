import React, { useState } from 'react';

export default function RenderSettingsPanel() {
  const [renderer, setRenderer] = useState('pbr');
  const [resolution, setResolution] = useState({ w: 1920, h: 1080 });
  const [quality, setQuality] = useState({ shadows: 'high', aa: 'msaa4', ao: true, bloom: true, ssr: false, dof: false });
  const [output, setOutput] = useState({ format: 'png', fps: 30 });

  return (
    <div className="panel-section">
      <div className="panel-header">Render Settings</div>
      <div className="panel-group">
        <div className="panel-label">Renderer</div>
        <div className="panel-row">
          {['pbr', 'toon', 'wireframe', 'xray'].map(r => (
            <button key={r} className={`panel-btn small ${renderer === r ? 'active' : ''}`}
              onClick={() => setRenderer(r)}>{r}</button>
          ))}
        </div>
      </div>

      <div className="panel-group">
        <div className="panel-label">Resolution</div>
        <div className="panel-row">
          <label>W</label>
          <input type="number" value={resolution.w} onChange={e => setResolution({ ...resolution, w: +e.target.value })} />
          <label>H</label>
          <input type="number" value={resolution.h} onChange={e => setResolution({ ...resolution, h: +e.target.value })} />
        </div>
        <div className="panel-row">
          {['720p', '1080p', '4K'].map(p => (
            <button key={p} className="panel-btn small" onClick={() => {
              const sizes = { '720p': [1280, 720], '1080p': [1920, 1080], '4K': [3840, 2160] };
              setResolution({ w: sizes[p][0], h: sizes[p][1] });
            }}>{p}</button>
          ))}
        </div>
      </div>

      <div className="panel-group">
        <div className="panel-label">Quality</div>
        <div className="panel-row">
          <label>Shadows</label>
          <select value={quality.shadows} onChange={e => setQuality({ ...quality, shadows: e.target.value })}>
            <option value="low">Low</option><option value="medium">Medium</option>
            <option value="high">High</option><option value="ultra">Ultra</option>
          </select>
        </div>
        <div className="panel-row">
          <label>AA</label>
          <select value={quality.aa} onChange={e => setQuality({ ...quality, aa: e.target.value })}>
            <option value="none">None</option><option value="fxaa">FXAA</option>
            <option value="msaa4">MSAA 4x</option><option value="msaa8">MSAA 8x</option>
          </select>
        </div>
        {[['ao', 'Ambient Occlusion'], ['bloom', 'Bloom'], ['ssr', 'Screen-Space Refl'], ['dof', 'Depth of Field']].map(([k, label]) => (
          <div className="panel-row" key={k}>
            <input type="checkbox" checked={quality[k]}
              onChange={e => setQuality({ ...quality, [k]: e.target.checked })} />
            <label>{label}</label>
          </div>
        ))}
      </div>

      <div className="panel-group">
        <div className="panel-row">
          <label>Format</label>
          <select value={output.format} onChange={e => setOutput({ ...output, format: e.target.value })}>
            <option>png</option><option>jpg</option><option>exr</option><option>mp4</option><option>webm</option>
          </select>
        </div>
        <div className="panel-row">
          <button className="panel-btn full-width primary">Render Frame</button>
        </div>
        <div className="panel-row">
          <button className="panel-btn full-width">Render Animation</button>
        </div>
      </div>
    </div>
  );
}
