import React, { useState } from 'react';

const PIPELINE_STEPS = [
  { id: 'import', label: 'Import', status: 'done' },
  { id: 'rig', label: 'Auto-Rig', status: 'done' },
  { id: 'skin', label: 'Skin Weights', status: 'active' },
  { id: 'cloth', label: 'Clothing Sim', status: 'pending' },
  { id: 'hair', label: 'Hair Groom', status: 'pending' },
  { id: 'material', label: 'Materials', status: 'pending' },
  { id: 'render', label: 'Render', status: 'pending' },
  { id: 'export', label: 'Export', status: 'pending' },
];

export default function PipelinePanel() {
  const [steps, setSteps] = useState(PIPELINE_STEPS);
  const [exportFmt, setExportFmt] = useState('gltf');

  return (
    <div className="panel-section">
      <div className="panel-header">Asset Pipeline</div>
      <div className="panel-group">
        <div className="panel-label">Pipeline Steps</div>
        <div className="pipeline-steps">
          {steps.map((step, i) => (
            <div key={step.id} className={`pipeline-step ${step.status}`}>
              <div className="step-indicator">{step.status === 'done' ? '✓' : i + 1}</div>
              <span>{step.label}</span>
              <span className={`step-badge ${step.status}`}>{step.status}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="panel-group">
        <div className="panel-label">Export</div>
        <div className="panel-row">
          <label>Format</label>
          <select value={exportFmt} onChange={e => setExportFmt(e.target.value)}>
            <option value="gltf">glTF 2.0</option>
            <option value="glb">GLB (Binary)</option>
            <option value="fbx">FBX</option>
            <option value="obj">OBJ</option>
            <option value="usd">USD</option>
            <option value="vrm">VRM</option>
          </select>
        </div>
        <div className="panel-row">
          <input type="checkbox" id="exp-anims" defaultChecked />
          <label htmlFor="exp-anims">Include Animations</label>
        </div>
        <div className="panel-row">
          <input type="checkbox" id="exp-mats" defaultChecked />
          <label htmlFor="exp-mats">Include Materials</label>
        </div>
        <div className="panel-row">
          <button className="panel-btn full-width primary">Export Asset</button>
        </div>
      </div>

      <div className="panel-group">
        <div className="panel-label">Validation</div>
        <div className="panel-row">
          <button className="panel-btn">Run Checks</button>
          <button className="panel-btn">Fix Issues</button>
        </div>
      </div>
    </div>
  );
}
