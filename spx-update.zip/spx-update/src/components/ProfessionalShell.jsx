import React, { useRef, useEffect, useState, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { TransformControls } from 'three/examples/jsm/controls/TransformControls.js';
import { GeometryEngine, PRIMITIVE_TYPES } from '../mesh/GeometryEngine';

/**
 * ProfessionalShell
 * – Workspace tabs: MODELING, SCULPT, ANIMATION, SHADING, PERFORMANCE
 * – 24 primitives via GeometryEngine
 * – Brighter grid (0x00ffc8 / 0x2a4a5a)
 * – Hosts the Three.js viewport
 */

const WORKSPACES = ['MODELING', 'SCULPT', 'ANIMATION', 'SHADING', 'PERFORMANCE'];

const MATERIAL_PRESETS = {
  default:   { color: 0x888888, roughness: 0.5, metalness: 0.0 },
  metal:     { color: 0xaaaacc, roughness: 0.1, metalness: 0.9 },
  plastic:   { color: 0xff4444, roughness: 0.7, metalness: 0.0 },
  glass:     { color: 0xaaddff, roughness: 0.0, metalness: 0.0, transparent: true, opacity: 0.4 },
  emissive:  { color: 0x00ffc8, roughness: 0.5, metalness: 0.0, emissive: 0x00ffc8, emissiveIntensity: 0.5 },
};

export default function ProfessionalShell({ children }) {
  const mountRef = useRef(null);
  const sceneRef = useRef(null);
  const cameraRef = useRef(null);
  const rendererRef = useRef(null);
  const orbitRef = useRef(null);
  const transformRef = useRef(null);
  const objectsRef = useRef([]);
  const selectedRef = useRef(null);
  const rafRef = useRef(null);

  const [workspace, setWorkspace] = useState('MODELING');
  const [primitive, setPrimitive] = useState('box');
  const [matPreset, setMatPreset] = useState('default');
  const [objectCount, setObjectCount] = useState(0);
  const [fps, setFps] = useState(60);
  const [transformMode, setTransformMode] = useState('translate');

  // Boot Three.js
  useEffect(() => {
    const el = mountRef.current;
    if (!el) return;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x111418);
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(60, el.clientWidth / el.clientHeight, 0.01, 2000);
    camera.position.set(3, 2.5, 4);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(el.clientWidth, el.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    el.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Orbit
    const orbit = new OrbitControls(camera, renderer.domElement);
    orbit.enableDamping = true;
    orbit.dampingFactor = 0.06;
    orbitRef.current = orbit;

    // Transform controls
    const transform = new TransformControls(camera, renderer.domElement);
    transform.addEventListener('dragging-changed', e => { orbit.enabled = !e.value; });
    scene.add(transform);
    transformRef.current = transform;

    // Lights
    const ambient = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambient);
    const sun = new THREE.DirectionalLight(0xfff5e0, 1.4);
    sun.position.set(5, 8, 5);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    scene.add(sun);
    const fill = new THREE.DirectionalLight(0x8899cc, 0.6);
    fill.position.set(-4, 3, -4);
    scene.add(fill);

    // Grid — brighter colors
    const grid = new THREE.GridHelper(20, 20, 0x00ffc8, 0x2a4a5a);
    grid.material.opacity = 0.6;
    grid.material.transparent = true;
    scene.add(grid);

    // Ground plane (shadow receiver)
    const groundGeo = new THREE.PlaneGeometry(40, 40);
    const groundMat = new THREE.ShadowMaterial({ opacity: 0.3 });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Default box
    _addMesh(scene, 'box', {}, MATERIAL_PRESETS.default);

    // Animate
    let lastTime = performance.now();
    let frameCount = 0;
    let fpsTimer = 0;

    function animate() {
      rafRef.current = requestAnimationFrame(animate);
      const now = performance.now();
      const dt = (now - lastTime) / 1000;
      lastTime = now;
      fpsTimer += dt;
      frameCount++;
      if (fpsTimer >= 1) {
        setFps(Math.round(frameCount / fpsTimer));
        frameCount = 0;
        fpsTimer = 0;
      }
      orbit.update();
      renderer.render(scene, camera);
    }
    animate();

    // Resize
    const ro = new ResizeObserver(() => {
      if (!el) return;
      camera.aspect = el.clientWidth / el.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(el.clientWidth, el.clientHeight);
    });
    ro.observe(el);

    return () => {
      cancelAnimationFrame(rafRef.current);
      ro.disconnect();
      transform.dispose();
      orbit.dispose();
      renderer.dispose();
      el.removeChild(renderer.domElement);
    };
  }, []);

  function _addMesh(scene, type, params, matParams) {
    const geo = GeometryEngine.create(type, params);
    const mat = new THREE.MeshStandardMaterial({ ...matParams });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.userData.primitiveType = type;
    scene.add(mesh);
    objectsRef.current.push(mesh);
    return mesh;
  }

  const handleAddPrimitive = useCallback(() => {
    const scene = sceneRef.current;
    if (!scene) return;
    const matParams = MATERIAL_PRESETS[matPreset] || MATERIAL_PRESETS.default;
    const mesh = _addMesh(scene, primitive, {}, matParams);
    // Offset slightly so objects don't stack
    const count = objectsRef.current.length;
    mesh.position.set((count % 5) * 1.2 - 2.4, 0, Math.floor(count / 5) * 1.2);
    setObjectCount(objectsRef.current.length);

    // Auto-select
    if (transformRef.current) {
      transformRef.current.attach(mesh);
      selectedRef.current = mesh;
    }
  }, [primitive, matPreset]);

  const handleDelete = useCallback(() => {
    const obj = selectedRef.current;
    if (!obj) return;
    transformRef.current?.detach();
    sceneRef.current?.remove(obj);
    obj.geometry.dispose();
    obj.material.dispose();
    objectsRef.current = objectsRef.current.filter(o => o !== obj);
    selectedRef.current = null;
    setObjectCount(objectsRef.current.length);
  }, []);

  // Sync transform mode
  useEffect(() => {
    if (transformRef.current) transformRef.current.setMode(transformMode);
  }, [transformMode]);

  return (
    <div className="professional-shell">
      {/* Workspace tab bar */}
      <div className="workspace-bar">
        <span className="shell-logo">SPX 3D</span>
        {WORKSPACES.map(ws => (
          <button
            key={ws}
            className={`ws-tab ${workspace === ws ? 'active' : ''}`}
            onClick={() => setWorkspace(ws)}
          >
            {ws}
          </button>
        ))}
        <div className="ws-spacer" />
        <span className="fps-badge">{fps} fps</span>
      </div>

      {/* Toolbar */}
      <div className="shell-toolbar">
        <div className="tool-section">
          {['translate', 'rotate', 'scale'].map(m => (
            <button key={m} className={`tool-btn ${transformMode === m ? 'active' : ''}`}
              onClick={() => setTransformMode(m)}>
              {m === 'translate' ? '✥' : m === 'rotate' ? '↻' : '⤢'}
            </button>
          ))}
        </div>
        <div className="tool-section">
          <select value={primitive} onChange={e => setPrimitive(e.target.value)}>
            {PRIMITIVE_TYPES.map(p => <option key={p} value={p}>{p}</option>)}
          </select>
          <select value={matPreset} onChange={e => setMatPreset(e.target.value)}>
            {Object.keys(MATERIAL_PRESETS).map(k => <option key={k} value={k}>{k}</option>)}
          </select>
          <button className="tool-btn primary" onClick={handleAddPrimitive}>+ Add</button>
          <button className="tool-btn danger" onClick={handleDelete}>✕ Delete</button>
        </div>
        <div className="tool-section">
          <span className="obj-count">Objects: {objectCount}</span>
        </div>
      </div>

      {/* Main content */}
      <div className="shell-body">
        {/* Viewport */}
        <div className="shell-viewport" ref={mountRef} />

        {/* Right sidebar — panels injected via children or App.jsx */}
        <aside className="shell-sidebar">
          {children}
        </aside>
      </div>
    </div>
  );
}
