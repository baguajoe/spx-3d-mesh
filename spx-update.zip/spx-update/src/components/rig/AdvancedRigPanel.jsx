import React, { useState } from 'react';

export default function AdvancedRigPanel() {
  const [bones, setBones] = useState([
    { id: 1, name: 'Root', parent: null, type: 'root' },
    { id: 2, name: 'Hips', parent: 1, type: 'core' },
    { id: 3, name: 'Spine_01', parent: 2, type: 'core' },
    { id: 4, name: 'Spine_02', parent: 3, type: 'core' },
    { id: 5, name: 'Chest', parent: 4, type: 'core' },
    { id: 6, name: 'L_Shoulder', parent: 5, type: 'arm' },
    { id: 7, name: 'R_Shoulder', parent: 5, type: 'arm' },
  ]);
  const [selected, setSelected] = useState(null);
  const [constraints, setConstraints] = useState([]);

  return (
    <div className="panel-section">
      <div className="panel-header">Advanced Rig</div>
      <div className="panel-group">
        <div className="panel-label">Bone Hierarchy</div>
        <div className="bone-tree">
          {bones.map(b => (
            <div key={b.id}
              className={`bone-item ${selected === b.id ? 'active' : ''}`}
              style={{ paddingLeft: `${(b.parent ? 16 : 0)}px` }}
              onClick={() => setSelected(b.id)}>
              <span className={`bone-type-dot ${b.type}`} />
              <span>{b.name}</span>
            </div>
          ))}
        </div>
        <div className="panel-row">
          <button className="panel-btn small">+ Bone</button>
          <button className="panel-btn small">Duplicate</button>
          <button className="panel-btn small">Delete</button>
        </div>
      </div>

      <div className="panel-group">
        <div className="panel-label">Constraints</div>
        <div className="panel-row">
          <select>
            <option>Copy Location</option>
            <option>Copy Rotation</option>
            <option>IK</option>
            <option>Look At</option>
            <option>Damped Track</option>
            <option>Stretch To</option>
          </select>
          <button className="panel-btn small">Add</button>
        </div>
        {constraints.length === 0 && <div className="panel-empty">No constraints</div>}
      </div>

      <div className="panel-group">
        <div className="panel-label">Shape Keys</div>
        <div className="panel-row">
          <button className="panel-btn">Add Shape Key</button>
          <button className="panel-btn">Driver</button>
        </div>
      </div>

      <div className="panel-group">
        <div className="panel-label">Custom Properties</div>
        <div className="panel-row">
          <button className="panel-btn">+ Property</button>
        </div>
      </div>
    </div>
  );
}
