import React, { useState } from 'react';

export default function AutoRigPanel() {
  const [rigType, setRigType] = useState('biped');
  const [markers, setMarkers] = useState({
    head: true, neck: true, spine: 3, shoulders: true, arms: true,
    hands: true, fingers: true, hips: true, legs: true, feet: true, toes: false
  });
  const [status, setStatus] = useState('idle');

  const handleBuild = () => {
    setStatus('building');
    setTimeout(() => setStatus('done'), 1500);
  };

  return (
    <div className="panel-section">
      <div className="panel-header">Auto-Rig</div>
      <div className="panel-group">
        <div className="panel-label">Rig Type</div>
        <div className="panel-row">
          {['biped', 'quadruped', 'bird', 'fish', 'custom'].map(t => (
            <button key={t} className={`panel-btn small ${rigType === t ? 'active' : ''}`}
              onClick={() => setRigType(t)}>{t}</button>
          ))}
        </div>
      </div>

      <div className="panel-group">
        <div className="panel-label">Bone Groups</div>
        {Object.entries(markers).map(([k, v]) => (
          <div className="panel-row" key={k}>
            {typeof v === 'boolean' ? (
              <>
                <input type="checkbox" checked={v}
                  onChange={e => setMarkers({ ...markers, [k]: e.target.checked })} />
                <label>{k}</label>
              </>
            ) : (
              <>
                <label>{k} segments</label>
                <input type="number" min="1" max="10" value={v}
                  onChange={e => setMarkers({ ...markers, [k]: +e.target.value })} />
              </>
            )}
          </div>
        ))}
      </div>

      <div className="panel-group">
        <div className="panel-label">IK / FK</div>
        <div className="panel-row">
          <label>Arms</label>
          <select><option>IK</option><option>FK</option><option>IK/FK Blend</option></select>
        </div>
        <div className="panel-row">
          <label>Legs</label>
          <select><option>IK</option><option>FK</option><option>IK/FK Blend</option></select>
        </div>
      </div>

      <div className="panel-group">
        <button className="panel-btn full-width primary" onClick={handleBuild}>
          {status === 'idle' ? 'Build Rig' : status === 'building' ? 'Building...' : '✓ Rig Built'}
        </button>
        <div className="panel-row">
          <button className="panel-btn">Place Markers</button>
          <button className="panel-btn">Weight Paint</button>
        </div>
        <div className="panel-row">
          <button className="panel-btn">Bind Mesh</button>
          <button className="panel-btn">Reset Pose</button>
        </div>
      </div>
    </div>
  );
}
