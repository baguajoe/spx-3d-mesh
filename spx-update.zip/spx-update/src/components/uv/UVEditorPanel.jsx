import React, { useState, useRef, useEffect } from 'react';

export default function UVEditorPanel() {
  const canvasRef = useRef(null);
  const [uvMode, setUvMode] = useState('select');
  const [unwrapMethod, setUnwrapMethod] = useState('smart');
  const [seams, setSeams] = useState([]);
  const [selectedUVs, setSelectedUVs] = useState([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    // Draw checkerboard background
    const size = 16;
    for (let y = 0; y < canvas.height; y += size) {
      for (let x = 0; x < canvas.width; x += size) {
        ctx.fillStyle = ((x / size + y / size) % 2 === 0) ? '#2a2a2a' : '#1a1a1a';
        ctx.fillRect(x, y, size, size);
      }
    }
    // Draw UV border
    ctx.strokeStyle = '#00ffc8';
    ctx.lineWidth = 1;
    ctx.strokeRect(20, 20, canvas.width - 40, canvas.height - 40);
    // Draw sample UV island
    ctx.strokeStyle = '#ff9900';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(60, 60); ctx.lineTo(160, 60);
    ctx.lineTo(160, 140); ctx.lineTo(60, 140);
    ctx.closePath();
    ctx.stroke();
  }, []);

  return (
    <div className="panel-section">
      <div className="panel-header">UV Editor</div>
      <div className="panel-toolbar">
        {['select', 'move', 'rotate', 'scale', 'pin'].map(m => (
          <button key={m} className={`tool-btn ${uvMode === m ? 'active' : ''}`}
            onClick={() => setUvMode(m)}>{m}</button>
        ))}
      </div>
      <canvas ref={canvasRef} width={280} height={200} className="uv-canvas" />
      <div className="panel-group">
        <div className="panel-label">Unwrap</div>
        <div className="panel-row">
          <label>Method</label>
          <select value={unwrapMethod} onChange={e => setUnwrapMethod(e.target.value)}>
            <option value="smart">Smart UV Project</option>
            <option value="angle">Angle-Based</option>
            <option value="conformal">Conformal</option>
            <option value="lightmap">Lightmap Pack</option>
            <option value="cube">Cube Projection</option>
            <option value="cylinder">Cylinder</option>
            <option value="sphere">Sphere</option>
          </select>
        </div>
        <div className="panel-row">
          <button className="panel-btn full-width">Unwrap</button>
          <button className="panel-btn full-width">Pack Islands</button>
        </div>
      </div>
      <div className="panel-group">
        <div className="panel-label">Seams</div>
        <div className="panel-row">
          <button className="panel-btn">Mark Seam</button>
          <button className="panel-btn">Clear Seam</button>
        </div>
        <div className="panel-row">
          <button className="panel-btn">Mark Sharp</button>
          <button className="panel-btn">Auto Seams</button>
        </div>
      </div>
    </div>
  );
}
