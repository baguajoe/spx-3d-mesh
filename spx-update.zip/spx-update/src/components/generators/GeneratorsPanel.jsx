import React, { useState } from 'react';

const GENERATORS = [
  { id: 'terrain', label: 'Terrain', icon: '⛰' },
  { id: 'city', label: 'City Block', icon: '🏙' },
  { id: 'forest', label: 'Forest', icon: '🌲' },
  { id: 'road', label: 'Road Network', icon: '🛣' },
  { id: 'crowd', label: 'Crowd', icon: '👥' },
  { id: 'rock', label: 'Rock Scatter', icon: '🪨' },
  { id: 'pipe', label: 'Pipe System', icon: '🔧' },
  { id: 'cable', label: 'Cable/Wire', icon: '〰' },
];

export default function GeneratorsPanel() {
  const [active, setActive] = useState('terrain');
  const [seed, setSeed] = useState(42);
  const [params, setParams] = useState({ scale: 1.0, density: 0.5, variation: 0.5 });

  return (
    <div className="panel-section">
      <div className="panel-header">Procedural Generators</div>
      <div className="panel-group">
        <div className="panel-label">Generator</div>
        <div className="generator-grid">
          {GENERATORS.map(g => (
            <button key={g.id} className={`gen-btn ${active === g.id ? 'active' : ''}`}
              onClick={() => setActive(g.id)}>
              <span className="gen-icon">{g.icon}</span>
              <span>{g.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="panel-group">
        <div className="panel-label">Parameters — {GENERATORS.find(g => g.id === active)?.label}</div>
        <div className="panel-row">
          <label>Seed</label>
          <input type="number" value={seed} onChange={e => setSeed(+e.target.value)} />
          <button className="panel-btn small" onClick={() => setSeed(Math.floor(Math.random() * 9999))}>🎲</button>
        </div>
        {Object.entries(params).map(([k, v]) => (
          <div className="panel-row" key={k}>
            <label>{k}</label>
            <input type="range" min="0" max="2" step="0.01" value={v}
              onChange={e => setParams({ ...params, [k]: +e.target.value })} />
            <span>{v.toFixed(2)}</span>
          </div>
        ))}
      </div>

      <div className="panel-group">
        <div className="panel-row">
          <button className="panel-btn full-width primary">Generate</button>
        </div>
        <div className="panel-row">
          <button className="panel-btn">Regenerate</button>
          <button className="panel-btn">Bake to Mesh</button>
        </div>
      </div>
    </div>
  );
}
