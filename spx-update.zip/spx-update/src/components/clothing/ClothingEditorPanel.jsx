import React, { useState } from 'react';

export default function ClothingEditorPanel() {
  const [garments, setGarments] = useState([
    { id: 1, name: 'T-Shirt', layer: 0, enabled: true },
    { id: 2, name: 'Jeans', layer: 1, enabled: true },
  ]);
  const [selected, setSelected] = useState(1);
  const [physics, setPhysics] = useState({ stiffness: 0.4, damping: 0.1, gravity: 1.0, wind: 0.0 });

  return (
    <div className="panel-section">
      <div className="panel-header">Clothing Editor</div>
      <div className="panel-group">
        <div className="panel-label">Garments</div>
        {garments.map(g => (
          <div key={g.id} className={`panel-item ${selected === g.id ? 'active' : ''}`}
            onClick={() => setSelected(g.id)}>
            <input type="checkbox" checked={g.enabled}
              onChange={e => setGarments(garments.map(gg => gg.id === g.id ? { ...gg, enabled: e.target.checked } : gg))}
              onClick={e => e.stopPropagation()} />
            <span>{g.name}</span>
            <span className="layer-badge">L{g.layer}</span>
          </div>
        ))}
        <button className="panel-btn" onClick={() => {
          const id = Date.now();
          setGarments([...garments, { id, name: 'New Garment', layer: garments.length, enabled: true }]);
          setSelected(id);
        }}>+ Add Garment</button>
      </div>

      <div className="panel-group">
        <div className="panel-label">Cloth Physics</div>
        {[['stiffness', 0, 1, 0.01], ['damping', 0, 1, 0.01], ['gravity', 0, 2, 0.1], ['wind', 0, 5, 0.1]].map(([k, min, max, step]) => (
          <div className="panel-row" key={k}>
            <label>{k}</label>
            <input type="range" min={min} max={max} step={step} value={physics[k]}
              onChange={e => setPhysics({ ...physics, [k]: +e.target.value })} />
            <span>{physics[k].toFixed(2)}</span>
          </div>
        ))}
      </div>

      <div className="panel-group">
        <div className="panel-label">Tools</div>
        <div className="panel-row">
          <button className="panel-btn">Fit to Body</button>
          <button className="panel-btn">Simulate</button>
        </div>
        <div className="panel-row">
          <button className="panel-btn">Pin Vertices</button>
          <button className="panel-btn">Sew Edges</button>
        </div>
      </div>
    </div>
  );
}
