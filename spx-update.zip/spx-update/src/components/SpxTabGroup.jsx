import React, { useState } from 'react';

/**
 * SpxTabGroup — renders a 6-tab panel group: SURFACE / RIG / RENDER / FX / WORLD / GEN
 * Each tab hosts multiple sub-panels passed as children or via the panels prop.
 */

export const TAB_IDS = ['SURFACE', 'RIG', 'RENDER', 'FX', 'WORLD', 'GEN'];

export function SpxTabGroup({ panels = {}, defaultTab = 'SURFACE', className = '' }) {
  const [activeTab, setActiveTab] = useState(defaultTab);

  const tabPanels = panels[activeTab] ?? [];

  return (
    <div className={`spx-tab-group ${className}`}>
      <div className="spx-tab-bar">
        {TAB_IDS.map(tab => (
          <button
            key={tab}
            className={`spx-tab ${activeTab === tab ? 'active' : ''}`}
            onClick={() => setActiveTab(tab)}
          >
            {tab}
          </button>
        ))}
      </div>
      <div className="spx-tab-content">
        {tabPanels.map((Panel, i) =>
          typeof Panel === 'function'
            ? <Panel key={i} />
            : React.isValidElement(Panel)
              ? React.cloneElement(Panel, { key: i })
              : null
        )}
        {tabPanels.length === 0 && (
          <div className="spx-tab-empty">
            <span>{activeTab}</span>
            <p>No panels configured for this tab.</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default SpxTabGroup;
