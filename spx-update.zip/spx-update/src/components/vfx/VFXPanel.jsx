import React, { useState } from 'react';

export default function VFXPanel() {
  const [systems, setSystems] = useState([
    { id: 1, name: 'Dust Trail', type: 'particles', enabled: true },
    { id: 2, name: 'Aura Glow', type: 'volumetric', enabled: false },
  ]);
  const [selected, setSelected] = useState(1);
  const [params, setParams] = useState({ emission: 100, lifetime: 2.0, speed: 1.0, size: 0.1, opacity: 0.8 });

  return (
    <div className="panel-section">
      <div className="panel-header">VFX</div>
      <div className="panel-group">
        <div className="panel-label">Effects</div>
        {systems.map(s => (
          <div key={s.id} className={`panel-item ${selected === s.id ? 'active' : ''}`}
            onClick={() => setSelected(s.id)}>
            <input type="checkbox" checked={s.enabled}
              onChange={e => setSystems(systems.map(ss => ss.id === s.id ? { ...ss, enabled: e.target.checked } : ss))}
              onClick={e => e.stopPropagation()} />
            <span>{s.name}</span>
            <span className="layer-badge">{s.type}</span>
          </div>
        ))}
        <button className="panel-btn">+ Add Effect</button>
      </div>

      <div className="panel-group">
        <div className="panel-label">Effect Type</div>
        <div className="panel-row">
          {['particles', 'volumetric', 'trails', 'decals', 'shockwave'].map(t => (
            <button key={t} className="panel-btn small">{t}</button>
          ))}
        </div>
      </div>

      <div className="panel-group">
        <div className="panel-label">Parameters</div>
        {[['emission', 0, 1000, 1], ['lifetime', 0.1, 10, 0.1], ['speed', 0, 5, 0.1], ['size', 0.01, 2, 0.01], ['opacity', 0, 1, 0.01]].map(([k, min, max, step]) => (
          <div className="panel-row" key={k}>
            <label>{k}</label>
            <input type="range" min={min} max={max} step={step} value={params[k]}
              onChange={e => setParams({ ...params, [k]: +e.target.value })} />
            <span>{params[k]}</span>
          </div>
        ))}
      </div>

      <div className="panel-group">
        <div className="panel-row">
          <button className="panel-btn">Preview</button>
          <button className="panel-btn">Bake</button>
          <button className="panel-btn">Reset</button>
        </div>
      </div>
    </div>
  );
}
