import React, { useState, useRef, useEffect, useCallback } from 'react';
import { SpxTabGroup } from './components/SpxTabGroup';
import { useSceneObjects } from './hooks/useSceneObjects';
import { useKeyboardShortcuts } from './hooks/useKeyboardShortcuts';

// Panel imports
import UVEditorPanel from './components/uv/UVEditorPanel';
import MaterialEditorPanel from './components/materials/MaterialEditorPanel';
import TexturePaintPanel from './components/materials/TexturePaintPanel';
import ClothingEditorPanel from './components/clothing/ClothingEditorPanel';
import HairEditorPanel from './components/hair/HairEditorPanel';
import AutoRigPanel from './components/rig/AutoRigPanel';
import AdvancedRigPanel from './components/rig/AdvancedRigPanel';
import AnimationPanel from './components/animation/AnimationPanel';
import MocapPanel from './components/animation/MocapPanel';
import VFXPanel from './components/vfx/VFXPanel';
import LightingCameraPanel from './components/scene/LightingCameraPanel';
import RenderSettingsPanel from './components/scene/RenderSettingsPanel';
import WorldSettingsPanel from './components/scene/WorldSettingsPanel';
import GeneratorsPanel from './components/generators/GeneratorsPanel';
import PipelinePanel from './components/pipeline/PipelinePanel';

// Tab → panel mapping
const TAB_PANELS = {
  SURFACE:  [UVEditorPanel, MaterialEditorPanel, TexturePaintPanel, ClothingEditorPanel, HairEditorPanel],
  RIG:      [AutoRigPanel, AdvancedRigPanel, AnimationPanel, MocapPanel],
  RENDER:   [LightingCameraPanel, RenderSettingsPanel],
  FX:       [VFXPanel],
  WORLD:    [WorldSettingsPanel],
  GEN:      [GeneratorsPanel, PipelinePanel],
};

export default function App() {
  // Scene state
  const {
    sceneObjects,
    sceneObjectsRef,
    addObject,
    removeObject,
    updateObject,
    selectObject,
    clearSelection,
    duplicateObject,
    getSelected,
  } = useSceneObjects();

  // UI state
  const [activeTool, setActiveTool] = useState('select');
  const [activeWorkspace, setActiveWorkspace] = useState('MODELING');
  const [showLeftPanel, setShowLeftPanel] = useState(true);
  const [showRightPanel, setShowRightPanel] = useState(true);
  const [showBottomPanel, setShowBottomPanel] = useState(false);
  const [transformMode, setTransformMode] = useState('translate');
  const [snapEnabled, setSnapEnabled] = useState(false);
  const [snapValue, setSnapValue] = useState(0.25);
  const [primitiveType, setPrimitiveType] = useState('box');
  const [shadingMode, setShadingMode] = useState('solid');

  // Viewport ref for Three.js canvas
  const viewportRef = useRef(null);

  // Keyboard shortcuts
  useKeyboardShortcuts({
    'g': () => setTransformMode('translate'),
    'r': () => setTransformMode('rotate'),
    's': () => setTransformMode('scale'),
    'delete': () => getSelected().forEach(o => removeObject(o.id)),
    'ctrl+d': () => getSelected().forEach(o => duplicateObject(o.id)),
    'ctrl+z': () => console.log('undo'),
    'ctrl+shift+z': () => console.log('redo'),
    'ctrl+a': () => sceneObjects.forEach(o => selectObject(o.id, true)),
    'escape': () => clearSelection(),
    'h': () => setShowLeftPanel(v => !v),
    'n': () => setShowRightPanel(v => !v),
  });

  // Canvas click handler using ref to avoid stale closure
  const onCanvasClick = useCallback((e) => {
    const objects = sceneObjectsRef.current;
    // Basic deselect on empty click (viewport handles actual raycasting)
    if (!e.shiftKey) clearSelection();
  }, [clearSelection, sceneObjectsRef]);

  return (
    <div className="app-root">
      {/* Header */}
      <header className="app-header">
        <div className="header-left">
          <span className="app-logo">SPX</span>
          <div className="workspace-tabs">
            {['MODELING', 'SCULPT', 'ANIMATION', 'SHADING', 'PERFORMANCE'].map(ws => (
              <button
                key={ws}
                className={`workspace-tab ${activeWorkspace === ws ? 'active' : ''}`}
                onClick={() => setActiveWorkspace(ws)}
              >
                {ws}
              </button>
            ))}
          </div>
        </div>
        <div className="header-right">
          <div className="tool-group">
            {[
              { id: 'select', label: '↖' },
              { id: 'move', label: '✥' },
              { id: 'rotate', label: '↻' },
              { id: 'scale', label: '⤢' },
              { id: 'add', label: '+' },
            ].map(t => (
              <button
                key={t.id}
                className={`header-tool-btn ${activeTool === t.id ? 'active' : ''}`}
                onClick={() => setActiveTool(t.id)}
                title={t.id}
              >
                {t.label}
              </button>
            ))}
          </div>
          <div className="shading-group">
            {['wireframe', 'solid', 'material', 'render'].map(m => (
              <button
                key={m}
                className={`shading-btn ${shadingMode === m ? 'active' : ''}`}
                onClick={() => setShadingMode(m)}
              >
                {m[0].toUpperCase()}
              </button>
            ))}
          </div>
          <label className="snap-toggle">
            <input type="checkbox" checked={snapEnabled} onChange={e => setSnapEnabled(e.target.checked)} />
            Snap {snapEnabled && <input type="number" value={snapValue} step="0.05" min="0.01"
              onChange={e => setSnapValue(+e.target.value)} className="snap-input" />}
          </label>
        </div>
      </header>

      {/* Main layout */}
      <div className="app-body">
        {/* Left panel — scene hierarchy */}
        {showLeftPanel && (
          <aside className="left-panel">
            <div className="panel-header">Scene</div>
            <div className="scene-list">
              {sceneObjects.map(obj => (
                <div
                  key={obj.id}
                  className={`scene-item ${obj.selected ? 'selected' : ''}`}
                  onClick={e => selectObject(obj.id, e.shiftKey)}
                >
                  <span className="obj-type-icon">◈</span>
                  <span>{obj.name}</span>
                </div>
              ))}
              {sceneObjects.length === 0 && (
                <div className="scene-empty">No objects</div>
              )}
            </div>
            <div className="panel-footer">
              <div className="add-primitive-row">
                <select value={primitiveType} onChange={e => setPrimitiveType(e.target.value)}>
                  {['box','sphere','cylinder','cone','torus','torusKnot','plane','circle',
                    'ring','capsule','icosphere','octahedron','tetrahedron','dodecahedron',
                    'lathe','tube','grid','stairs','arch','arrow','star','helix',
                    'extrude','text3d'].map(p => (
                    <option key={p} value={p}>{p}</option>
                  ))}
                </select>
                <button className="panel-btn primary" onClick={() => addObject(primitiveType)}>Add</button>
              </div>
            </div>
          </aside>
        )}

        {/* Viewport */}
        <main className="viewport-area" onClick={onCanvasClick} ref={viewportRef}>
          {/* Viewport component is mounted here externally by the shell */}
          <div className="viewport-overlay-tools">
            <div className="transform-gizmo-hint">
              {transformMode.toUpperCase()}
            </div>
          </div>
        </main>

        {/* Right panel — SpxTabGroup */}
        {showRightPanel && (
          <aside className="right-panel">
            <SpxTabGroup panels={TAB_PANELS} defaultTab="SURFACE" />
          </aside>
        )}
      </div>

      {/* Bottom panel (timeline / console) */}
      {showBottomPanel && (
        <div className="bottom-panel">
          <AnimationPanel />
        </div>
      )}

      {/* Status bar */}
      <footer className="status-bar">
        <span>Objects: {sceneObjects.length}</span>
        <span>Selected: {sceneObjects.filter(o => o.selected).length}</span>
        <span>Tool: {activeTool}</span>
        <span>Mode: {shadingMode}</span>
        <button className="status-btn" onClick={() => setShowBottomPanel(v => !v)}>
          Timeline {showBottomPanel ? '▼' : '▲'}
        </button>
      </footer>
    </div>
  );
}
