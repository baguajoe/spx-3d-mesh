import { useState, useRef, useCallback, useEffect } from 'react';
import * as THREE from 'three';

let _idCounter = 1;
const nextId = () => `obj_${_idCounter++}`;

export function useSceneObjects() {
  const [sceneObjects, setSceneObjects] = useState([]);
  const sceneObjectsRef = useRef(sceneObjects);

  useEffect(() => {
    sceneObjectsRef.current = sceneObjects;
  }, [sceneObjects]);

  const addObject = useCallback((type, params = {}) => {
    const id = nextId();
    const obj = {
      id,
      type,
      name: params.name ?? `${type}_${id}`,
      position: params.position ?? [0, 0, 0],
      rotation: params.rotation ?? [0, 0, 0],
      scale: params.scale ?? [1, 1, 1],
      material: params.material ?? { color: '#888888', roughness: 0.5, metalness: 0.0 },
      visible: true,
      selected: false,
      primitiveParams: params.primitiveParams ?? {},
      ...params,
    };
    setSceneObjects(prev => [...prev, obj]);
    return id;
  }, []);

  const removeObject = useCallback((id) => {
    setSceneObjects(prev => prev.filter(o => o.id !== id));
  }, []);

  const updateObject = useCallback((id, updates) => {
    setSceneObjects(prev => prev.map(o => o.id === id ? { ...o, ...updates } : o));
  }, []);

  const selectObject = useCallback((id, multi = false) => {
    setSceneObjects(prev => prev.map(o => ({
      ...o,
      selected: multi ? (o.id === id ? !o.selected : o.selected) : o.id === id
    })));
  }, []);

  const clearSelection = useCallback(() => {
    setSceneObjects(prev => prev.map(o => ({ ...o, selected: false })));
  }, []);

  const duplicateObject = useCallback((id) => {
    const obj = sceneObjectsRef.current.find(o => o.id === id);
    if (!obj) return;
    const newId = nextId();
    const dup = {
      ...JSON.parse(JSON.stringify(obj)),
      id: newId,
      name: obj.name + '_copy',
      position: [obj.position[0] + 0.2, obj.position[1], obj.position[2] + 0.2],
      selected: true,
    };
    setSceneObjects(prev => [
      ...prev.map(o => ({ ...o, selected: false })),
      dup
    ]);
    return newId;
  }, []);

  const getSelected = useCallback(() => {
    return sceneObjectsRef.current.filter(o => o.selected);
  }, []);

  return {
    sceneObjects,
    sceneObjectsRef,
    addObject,
    removeObject,
    updateObject,
    selectObject,
    clearSelection,
    duplicateObject,
    getSelected,
  };
}

export default useSceneObjects;
