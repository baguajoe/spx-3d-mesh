import { useEffect, useCallback } from 'react';

export function useKeyboardShortcuts(handlers = {}) {
  const handleKeyDown = useCallback((e) => {
    // Don't fire when typing in inputs
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return;

    const key = e.key.toLowerCase();
    const ctrl = e.ctrlKey || e.metaKey;
    const shift = e.shiftKey;
    const alt = e.altKey;

    const combo = [
      ctrl && 'ctrl',
      shift && 'shift',
      alt && 'alt',
      key
    ].filter(Boolean).join('+');

    if (handlers[combo]) {
      e.preventDefault();
      handlers[combo](e);
      return;
    }
    if (handlers[key]) {
      e.preventDefault();
      handlers[key](e);
    }
  }, [handlers]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);
}

export default useKeyboardShortcuts;
